# Volt Lot — voltlot.ai

Used Tesla inventory app for Volt Lot (1021 Market St, Paterson NJ).

## Deploy

### GitHub Pages (recommended)
1. Push this repo to GitHub
2. Go to **Settings → Pages → Source → Deploy from branch → main**
3. Add custom domain `voltlot.ai` under Settings → Pages → Custom domain
4. Set DNS: CNAME record `voltlot.ai` → `<your-username>.github.io`

### Netlify
1. Drag this folder into [app.netlify.com/drop](https://app.netlify.com/drop)
2. Set custom domain to `voltlot.ai`

### Vercel
1. `npx vercel --prod`
2. Add domain `voltlot.ai` in project settings

### Cloudflare Pages
1. Connect repo → Framework preset: None → Build command: (empty) → Output: `/`

## Contact
- **Phone:** 855-VOLT-LOT (855-865-8568)
- **Email:** sales@voltlot.ai
- **Address:** 1021 Market St, Paterson, NJ 07513

## Stack
Single-file HTML/CSS/JS. No build step. No dependencies. No npm.
60 real Tesla listings pulled from live inventory.
